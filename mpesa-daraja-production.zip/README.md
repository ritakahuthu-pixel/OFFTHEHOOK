# M-Pesa Daraja Production STK Push

Production-ready STK Push + Query integration.